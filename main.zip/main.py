from sea_level_predictor import draw_plot

# Generate the plot
draw_plot()
