import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress

def draw_plot():
    # 1. Read the data
    df = pd.read_csv('epa-sea-level.csv')

    # 2. Create scatter plot
    plt.figure(figsize=(10, 6))
    plt.scatter(df['Year'], df['CSIRO Adjusted Sea Level'], label='Actual Data')

    # 3. Full regression (1880 to 2050)
    res_full = linregress(df['Year'], df['CSIRO Adjusted Sea Level'])
    x_full = pd.Series(range(1880, 2051))
    y_full = res_full.slope * x_full + res_full.intercept
    plt.plot(x_full, y_full, 'r', label='Best Fit Line (1880–2050)')

    # 4. Regression from year 2000
    df_2000 = df[df['Year'] >= 2000]
    res_2000 = linregress(df_2000['Year'], df_2000['CSIRO Adjusted Sea Level'])
    x_2000 = pd.Series(range(2000, 2051))
    y_2000 = res_2000.slope * x_2000 + res_2000.intercept
    plt.plot(x_2000, y_2000, 'green', label='Best Fit Line (2000–2050)')

    # 5. Chart labels and title
    plt.title('Rise in Sea Level')
    plt.xlabel('Year')
    plt.ylabel('Sea Level (inches)')
    plt.legend()

    # 6. Save and return figure
    plt.savefig('sea_level_plot.png')
    return plt.gcf()
